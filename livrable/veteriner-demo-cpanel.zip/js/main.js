/* İstanbul Veteriner Kliniği — scripts (aucune dépendance) */
(function () {
  "use strict";

  // Numéro WhatsApp de démo (format international sans +)
  var WHATSAPP = "902120000000";

  /* ---------- Traductions EN (le TR est lu directement dans le HTML) ---------- */
  var EN = {
    "demo": "Demo website designed by <a href=\"https://wabina.com\" target=\"_blank\" rel=\"noopener\">Wabina</a>",
    "nav.home": "Home", "nav.services": "Services", "nav.about": "About", "nav.contact": "Contact",
    "cta": "Book Appointment", "call": "Call now", "menu.emergency": "24/7 Emergency",

    "home.tag": "Istanbul's trusted veterinary clinic",
    "home.title": "Expert, <span class=\"text-style-highlight\">compassionate</span> care for your companions",
    "home.text": "Modern equipment, experienced vets and 24/7 emergency support keep your cats, dogs and exotic pets healthy.",
    "home.secondary": "Our services",
    "home.rating": "<strong>4.9/5</strong> · 850+ Google reviews",
    "home.badge1": "<strong>24/7 Emergency</strong>Always by your side",
    "home.badge2": "<strong>12,000+</strong>Happy patients",
    "stats.1": "Years of experience", "stats.2": "Happy patients", "stats.3": "Emergency care", "stats.4": "Satisfaction",

    "why.eyebrow": "Why us", "why.title": "Why choose us?",
    "why.text": "We combine evidence-based medicine with a calm, gentle approach so every visit is stress-free.",
    "why.1.t": "Expert Team", "why.1.d": "Specialist vets committed to continuous training.",
    "why.2.t": "Modern Technology", "why.2.d": "Digital X-ray, ultrasound and a full in-house lab.",
    "why.3.t": "Gentle Approach", "why.3.d": "Fear-free, low-stress examinations.",

    "srv.eyebrow": "Services", "srv.title": "Everything your pet needs, under one roof",
    "srv.all": "All services",
    "s1.t": "General Check-up", "s1.d": "Regular wellness exams and health checks.",
    "s2.t": "Vaccination", "s2.d": "Age and species specific vaccine plans.",
    "s3.t": "Surgery", "s3.d": "Neutering and soft tissue procedures.",
    "s4.t": "Dental Care", "s4.d": "Scaling and oral health care.",
    "s5.t": "Imaging", "s5.d": "Digital X-ray and ultrasound.",
    "s6.t": "Emergency", "s6.d": "24/7 emergency and intensive care.",
    "s1.l1": "Full physical exam", "s1.l2": "Blood & urine tests", "s1.l3": "Nutrition advice",
    "s2.l1": "Puppy & kitten schedules", "s2.l2": "Rabies & combo vaccines", "s2.l3": "Microchip & pet passport",
    "s3.l1": "Spay & neuter", "s3.l2": "Soft tissue surgery", "s3.l3": "Monitored anaesthesia",
    "s4.l1": "Ultrasonic scaling", "s4.l2": "Tooth extraction", "s4.l3": "Dental X-ray",
    "s5.l1": "Digital X-ray", "s5.l2": "Abdominal ultrasound", "s5.l3": "Same-day results",
    "s6.l1": "Open 24/7", "s6.l2": "Intensive care unit", "s6.l3": "Fast triage",

    "proc.eyebrow": "How it works", "proc.title": "Your visit in 4 simple steps",
    "p1.t": "Book", "p1.d": "Online, by phone or WhatsApp — in under a minute.",
    "p2.t": "Welcome", "p2.d": "A calm waiting area separated for cats and dogs.",
    "p3.t": "Examination", "p3.d": "A full check-up and a clear explanation of the diagnosis.",
    "p4.t": "Follow-up", "p4.d": "Reminders for vaccines and check-ups, by SMS.",

    "test.eyebrow": "Reviews", "test.title": "What pet parents say",
    "t1.q": "\"Our cat Pamuk was terrified of vets. Here she was calm from start to finish — the team is incredibly gentle.\"",
    "t1.r": "Cat owner, Beşiktaş",
    "t2.q": "\"They took care of Max in the middle of the night for an emergency. Professional, fast, and they explained everything.\"",
    "t2.r": "Dog owner, Şişli",
    "t3.q": "\"Clean clinic, modern equipment and fair prices. I wouldn't trust anyone else with my rabbit.\"",
    "t3.r": "Rabbit owner, Kadıköy",

    "faq.eyebrow": "FAQ", "faq.title": "Frequently asked questions",
    "f1.q": "Do I need an appointment?", "f1.a": "We recommend it to avoid waiting, but emergencies are seen 24/7 without an appointment.",
    "f2.q": "Which animals do you treat?", "f2.a": "Cats, dogs, rabbits, birds and most small exotic pets.",
    "f3.q": "Can I pay by card?", "f3.a": "Yes, we accept all cards, cash and instalment payments for surgery.",
    "f4.q": "Do you offer home visits?", "f4.a": "Yes, for vaccinations and check-ups in Beşiktaş and nearby districts, by appointment.",

    "ctab.title": "Ready to book a visit?", "ctab.text": "Our team will call you back within the hour to confirm your appointment.",

    "srvp.title": "Our Services", "srvp.text": "From preventive care to advanced surgery, everything your pet needs under one roof.",
    "about.title": "About Us",
    "about.text": "Serving Istanbul since 2010, our clinic treats every patient as part of our family. Our team combines evidence-based medicine with genuine love for animals.",
    "story.eyebrow": "Our story", "story.title": "15 years of care, one family",
    "story.p1": "Founded in Beşiktaş in 2010 by Dr. Emre Yılmaz, our clinic started as a small practice with a simple idea: treat every animal the way we'd treat our own.",
    "story.p2": "Today our team of vets, technicians and assistants welcomes thousands of patients each year in a modern, fully equipped facility.",
    "val.1.t": "Fear-free certified", "val.1.d": "Low-stress handling techniques for every patient.",
    "val.2.t": "Transparent pricing", "val.2.d": "A clear estimate before every treatment.",
    "team.eyebrow": "The team", "team.title": "Meet our vets",
    "team.1": "Founder, Surgeon", "team.2": "Internal Medicine", "team.3": "Feline Specialist",
    "team.1.d": "20 years of experience in soft tissue and orthopaedic surgery.",
    "team.2.d": "Expert in diagnostics, cardiology and chronic disease management.",
    "team.3.d": "Dedicated to cat medicine and stress-free feline care.",

    "contact.title": "Contact & Appointments", "contact.text": "Fill in the form and we'll call you back shortly.",
    "form.name": "Your name", "form.phone": "Phone", "form.pet": "Type of pet", "form.date": "Preferred date",
    "form.service": "Service", "form.msg": "Message", "form.send": "Send request",
    "form.note": "Your request will be sent via WhatsApp for a faster reply.",
    "form.ok": "Thank you! Your request has been received.", "form.ok2": "We'll call you back as soon as possible.",
    "form.again": "New request",
    "pet.choose": "Choose…", "pet.cat": "Cat", "pet.dog": "Dog", "pet.rabbit": "Rabbit", "pet.bird": "Bird", "pet.other": "Other",
    "ph.name": "John Smith", "ph.msg": "Tell us briefly about your pet…",
    "info.address": "Address", "info.phone": "Phone", "info.hours": "Opening hours",
    "info.hoursVal": "Mon–Sat 09:00–20:00", "info.emergency": "Emergency line", "info.emergencyVal": "Open 24/7, 365 days a year",

    "footer.text": "Expert, compassionate veterinary care in the heart of Istanbul since 2010.",
    "footer.pages": "Pages", "footer.services": "Services", "footer.contact": "Contact",
    "footer.rights": "All rights reserved.",
    "nf.title": "Page not found", "nf.text": "The page you're looking for doesn't exist or has been moved.", "nf.btn": "Back to home"
  };

  var root = document.documentElement;
  var nodes = document.querySelectorAll("[data-i18n]");
  var phNodes = document.querySelectorAll("[data-i18n-ph]");

  // Mémorise la version turque d'origine
  nodes.forEach(function (el) { el.dataset.tr = el.innerHTML; });
  phNodes.forEach(function (el) { el.dataset.trPh = el.getAttribute("placeholder") || ""; });

  function setLang(lang) {
    nodes.forEach(function (el) {
      var k = el.dataset.i18n;
      el.innerHTML = lang === "en" && EN[k] ? EN[k] : el.dataset.tr;
    });
    phNodes.forEach(function (el) {
      var k = el.dataset.i18nPh;
      el.setAttribute("placeholder", lang === "en" && EN[k] ? EN[k] : el.dataset.trPh);
    });
    root.lang = lang;
    document.querySelectorAll(".lang-switch_button").forEach(function (b) {
      var on = b.dataset.lang === lang;
      b.classList.toggle("is-active", on);
      b.setAttribute("aria-pressed", on);
    });
    try { localStorage.setItem("vet-lang", lang); } catch (e) {}
  }

  document.querySelectorAll(".lang-switch_button").forEach(function (b) {
    b.addEventListener("click", function () { setLang(b.dataset.lang); });
  });
  var saved = null;
  try { saved = localStorage.getItem("vet-lang"); } catch (e) {}
  if (saved === "en") setLang("en");

  /* ---------- Navbar : ombre au scroll ---------- */
  var nav = document.querySelector(".navbar_component");
  function onScroll() { if (nav) nav.classList.toggle("is-scrolled", window.scrollY > 8); }
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  /* ---------- Menu mobile ---------- */
  var mobile = document.querySelector(".navbar_mobile");
  function toggleMenu(open) {
    if (!mobile) return;
    mobile.classList.toggle("is-open", open);
    mobile.setAttribute("aria-hidden", !open);
    document.body.style.overflow = open ? "hidden" : "";
  }
  document.querySelectorAll("[data-menu-open]").forEach(function (b) { b.addEventListener("click", function () { toggleMenu(true); }); });
  document.querySelectorAll("[data-menu-close]").forEach(function (b) { b.addEventListener("click", function () { toggleMenu(false); }); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") toggleMenu(false); });

  /* ---------- Apparition au scroll ---------- */
  var reveals = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add("is-visible"); io.unobserve(en.target); }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
    reveals.forEach(function (el) { io.observe(el); });
  } else {
    reveals.forEach(function (el) { el.classList.add("is-visible"); });
  }

  /* ---------- Compteurs animés ---------- */
  var counters = document.querySelectorAll("[data-count]");
  function animateCount(el) {
    var target = parseFloat(el.dataset.count);
    var suffix = el.dataset.suffix || "";
    var dur = 1600, start = null;
    var fmt = function (n) { return Math.round(n).toLocaleString(root.lang === "en" ? "en-US" : "tr-TR"); };
    function step(ts) {
      if (!start) start = ts;
      var p = Math.min((ts - start) / dur, 1);
      var eased = 1 - Math.pow(1 - p, 3); // ease-out cubique
      el.textContent = fmt(target * eased) + suffix;
      if (p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }
  if ("IntersectionObserver" in window && !matchMedia("(prefers-reduced-motion: reduce)").matches) {
    var co = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { animateCount(en.target); co.unobserve(en.target); } });
    }, { threshold: 0.6 });
    counters.forEach(function (el) { co.observe(el); });
  }

  /* ---------- Formulaire : envoi via WhatsApp (site statique) ---------- */
  var form = document.querySelector("[data-appointment-form]");
  if (form) {
    var wrap = form.closest(".form_component");
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var ok = true;
      form.querySelectorAll("[required]").forEach(function (f) {
        var bad = !f.value.trim();
        f.classList.toggle("is-invalid", bad);
        if (bad && ok) { f.focus(); ok = false; }
      });
      if (!ok) return;

      var d = new FormData(form);
      var sel = form.querySelector("select[name=pet]");
      var petLabel = sel && sel.selectedIndex > 0 ? sel.options[sel.selectedIndex].text : "-";
      var srvSel = form.querySelector("select[name=service]");
      var srvLabel = srvSel && srvSel.selectedIndex > 0 ? srvSel.options[srvSel.selectedIndex].text : "-";
      var lines = [
        root.lang === "en" ? "Appointment request" : "Randevu talebi",
        "—",
        "👤 " + d.get("name"),
        "📞 " + d.get("phone"),
        "🐾 " + petLabel,
        "🩺 " + srvLabel,
        "📅 " + (d.get("date") || "-"),
        d.get("message") ? "💬 " + d.get("message") : ""
      ].filter(Boolean);
      window.open("https://wa.me/" + WHATSAPP + "?text=" + encodeURIComponent(lines.join("\n")), "_blank", "noopener");
      wrap.classList.add("is-sent");
      form.reset();
    });
    form.querySelectorAll("[required]").forEach(function (f) {
      f.addEventListener("input", function () { f.classList.remove("is-invalid"); });
    });
    var again = document.querySelector("[data-form-again]");
    if (again) again.addEventListener("click", function () { wrap.classList.remove("is-sent"); });
  }

  /* ---------- Année du footer ---------- */
  document.querySelectorAll("[data-year]").forEach(function (el) { el.textContent = new Date().getFullYear(); });
})();
