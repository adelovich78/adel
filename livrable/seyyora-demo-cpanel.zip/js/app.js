/* ==========================================================================
   Seyyora — logique de la démo statique (aucun backend)
   Les réservations sont stockées dans le localStorage du visiteur.
   ========================================================================== */
(function () {
  "use strict";

  var D = window.SEYYORA;
  var LANGS = ["tr", "en", "fr"];
  var KEY_LANG = "seyyora_lang";
  var KEY_BOOKINGS = "seyyora_bookings";
  var KEY_CONTACT = "seyyora_contact";
  var page = document.body.getAttribute("data-page") || "";
  var lang = document.documentElement.lang;
  if (LANGS.indexOf(lang) < 0) lang = "fr";

  /* ---------- Stockage sécurisé (navigation privée, stockage bloqué…) ---------- */
  var store = {
    get: function (k, fallback) {
      try { var v = localStorage.getItem(k); return v === null ? fallback : JSON.parse(v); } catch (e) { return fallback; }
    },
    set: function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  };

  /* ---------- Helpers ---------- */
  var $ = function (s, root) { return (root || document).querySelector(s); };
  var $$ = function (s, root) { return Array.prototype.slice.call((root || document).querySelectorAll(s)); };
  var t = function (k) { return (D.i18n[k] && D.i18n[k][lang]) || k; };
  var tx = function (v) { return v ? v[lang] : ""; };
  var esc = function (s) { return String(s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var icon = function (name, cls) { return '<svg class="icon ' + (cls || "") + '" viewBox="0 0 24 24" aria-hidden="true">' + D.icons[name] + "</svg>"; };
  var locale = function () { return { tr: "tr-TR", en: "en-GB", fr: "fr-FR" }[lang]; };
  var price = function (n) { return new Intl.NumberFormat(locale(), { maximumFractionDigits: 0 }).format(n) + " €"; };
  var rating = function (n) { return new Intl.NumberFormat(locale(), { minimumFractionDigits: 1, maximumFractionDigits: 1 }).format(n); };
  var offerById = function (id) { return D.offers.filter(function (o) { return o.id === id; })[0]; };
  var norm = function (s) { return String(s || "").toLocaleLowerCase("tr").normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/ı/g, "i"); };
  var catPage = function (c) { return c + ".html"; };

  // Dates au format AAAA-MM-JJ en heure locale
  var iso = function (d) { var z = function (n) { return (n < 10 ? "0" : "") + n; }; return d.getFullYear() + "-" + z(d.getMonth() + 1) + "-" + z(d.getDate()); };
  var addDays = function (s, n) { var d = new Date(s + "T00:00:00"); d.setDate(d.getDate() + n); return iso(d); };
  var diffDays = function (a, b) { return Math.round((new Date(b + "T00:00:00") - new Date(a + "T00:00:00")) / 86400000); };
  var today = iso(new Date());
  var fmtDate = function (s) { return s ? new Date(s + "T00:00:00").toLocaleDateString(locale(), { day: "numeric", month: "short", year: "numeric" }) : "—"; };

  /* ---------- Réservations ---------- */
  var bookings = function () { var b = store.get(KEY_BOOKINGS, []); return Array.isArray(b) ? b : []; };
  var saveBookings = function (list) { store.set(KEY_BOOKINGS, list); updateCount(); };
  function updateCount() {
    var n = bookings().filter(function (b) { return b.status === "confirmed"; }).length;
    $$("[data-bookings-count]").forEach(function (el) { el.textContent = n ? String(n) : ""; });
  }

  /* ---------- Toasts ---------- */
  function toast(msg, link) {
    var wrap = $(".toast_wrapper");
    var el = document.createElement("div");
    el.className = "toast_item";
    el.innerHTML = icon("check") + "<span>" + esc(msg) + "</span>" + (link ? '<a href="' + link.href + '">' + esc(link.label) + "</a>" : "");
    wrap.appendChild(el);
    setTimeout(function () { el.classList.add("is-leaving"); setTimeout(function () { el.remove(); }, 220); }, 4200);
  }

  /* ---------- Carte offre ---------- */
  function unitLabel(u) { return t(u); }
  function offerCard(o) {
    return '<article class="offer_card reveal">' +
      '<div class="offer_image-wrapper"><img src="images/' + o.image + '.webp" alt="' + esc(tx(o.title)) + '" loading="lazy" class="offer_image">' +
      '<span class="offer_rating">' + icon("star") + rating(o.rating) + "</span>" +
      '<span class="offer_zone">' + (o.zone === "turquie" ? t("turkey") : t("world")) + "</span></div>" +
      '<div class="offer_content">' +
      '<p class="text-style-eyebrow text-color-primary">' + esc(tx(o.place)) + "</p>" +
      '<h3 class="heading-style-h4 margin-top margin-tiny">' + esc(tx(o.title)) + "</h3>" +
      '<div class="offer_tags">' + o.tags.map(function (g) { return '<span class="offer_tag">' + esc(tx(g)) + "</span>"; }).join("") + "</div>" +
      '<div class="offer_footer"><p><span class="offer_price">' + price(o.price) + '</span> <span class="text-size-small text-color-muted">/ ' + unitLabel(o.unit) + "</span></p>" +
      '<button type="button" class="button is-secondary is-small" data-book="' + o.id + '">' + t("book") + "</button></div>" +
      "</div></article>";
  }

  /* ---------- i18n ---------- */
  function applyI18n() {
    document.documentElement.lang = lang;
    $$("[data-i18n]").forEach(function (el) { el.textContent = t(el.getAttribute("data-i18n")); });
    $$("[data-i18n-ph]").forEach(function (el) { var v = t(el.getAttribute("data-i18n-ph")); el.placeholder = v; el.setAttribute("aria-label", v); });
    $$(".lang_button").forEach(function (b) { b.classList.toggle("is-active", b.getAttribute("data-lang") === lang); b.setAttribute("aria-pressed", b.getAttribute("data-lang") === lang); });
    renderPage();
  }
  $$(".lang_button").forEach(function (b) {
    b.addEventListener("click", function () { lang = b.getAttribute("data-lang"); try { localStorage.setItem(KEY_LANG, lang); } catch (e) {} applyI18n(); });
  });

  /* ---------- Menu mobile ---------- */
  var menuBtn = $(".navbar_menu-button"), mobileMenu = $(".navbar_mobile");
  if (menuBtn) menuBtn.addEventListener("click", function () {
    var open = mobileMenu.classList.toggle("is-open");
    menuBtn.setAttribute("aria-expanded", open);
    menuBtn.innerHTML = '<span class="sr-only">' + t("menu") + "</span>" + icon(open ? "x" : "menu");
  });

  /* ---------- Apparition au scroll ---------- */
  var io = "IntersectionObserver" in window ? new IntersectionObserver(function (entries) {
    entries.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add("is-visible"); io.unobserve(e.target); } });
  }, { rootMargin: "0px 0px -8% 0px" }) : null;
  function observeReveal() {
    $$(".reveal:not(.is-visible)").forEach(function (el, i) {
      if (!io) { el.classList.add("is-visible"); return; }
      el.style.transitionDelay = (el.classList.contains("offer_card") ? (i % 3) * 70 : 0) + "ms";
      io.observe(el);
    });
  }

  /* ==========================================================================
     Modale de réservation
     ========================================================================== */
  var modal = $("#booking-modal"), form = $("[data-modal-form]"), current = null, lastFocus = null;
  var prefill = {}; // dates/voyageurs venant de la recherche

  function isRange(o) { return o.unit === "night" || o.unit === "day"; }

  function computeTotal() {
    if (!current) return 0;
    var f = form.elements, guests = Math.max(1, Math.min(12, parseInt(f.guests.value, 10) || 1));
    var qty, label;
    if (isRange(current)) {
      qty = f.start.value && f.end.value ? Math.max(1, diffDays(f.start.value, f.end.value)) : 1;
      label = price(current.price) + " × " + qty + " " + t(current.unit === "night" ? (qty > 1 ? "nights" : "night") : (qty > 1 ? "days" : "day"));
    } else {
      qty = guests;
      label = price(current.price) + " × " + qty + " " + t("person");
    }
    var total = current.price * qty;
    $("[data-modal-calc]").textContent = label;
    $("[data-modal-sub]").textContent = price(total);
    $("[data-modal-total]").textContent = price(total);
    return total;
  }

  function openModal(o) {
    current = o; lastFocus = document.activeElement;
    var f = form.elements, contact = store.get(KEY_CONTACT, {});
    $("[data-modal-image]").src = "images/" + o.image + ".webp";
    $("[data-modal-place]").textContent = tx(o.place);
    $("[data-modal-title]").textContent = tx(o.title);
    $("[data-modal-start-label]").textContent = t(isRange(o) ? "from" : "date");
    $("[data-modal-end-wrap]").classList.toggle("hide", !isRange(o));
    f.start.min = today;
    f.start.value = prefill.from && prefill.from >= today ? prefill.from : addDays(today, 14);
    f.end.required = isRange(o);
    f.end.min = addDays(f.start.value, 1);
    f.end.value = prefill.to && prefill.to > f.start.value ? prefill.to : addDays(f.start.value, 3);
    f.guests.value = prefill.guests || 2;
    f.name.value = contact.name || "";
    f.email.value = contact.email || "";
    computeTotal();
    modal.classList.add("is-open");
    modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("is-locked");
    setTimeout(function () { f.start.focus(); }, 60);
  }
  function closeModal() {
    modal.classList.remove("is-open");
    modal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("is-locked");
    if (lastFocus) lastFocus.focus();
  }

  form.addEventListener("input", function (e) {
    var f = form.elements;
    // La date de fin suit toujours la date de début
    if (e.target === f.start && f.start.value) {
      f.end.min = addDays(f.start.value, 1);
      if (!f.end.value || f.end.value <= f.start.value) f.end.value = addDays(f.start.value, 1);
    }
    computeTotal();
  });
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    if (!form.reportValidity()) return;
    var f = form.elements, total = computeTotal();
    var b = {
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      ref: "SY-" + Math.random().toString(36).slice(2, 8).toUpperCase(),
      offerId: current.id,
      start: f.start.value,
      end: isRange(current) ? f.end.value : null,
      guests: parseInt(f.guests.value, 10) || 1,
      name: f.name.value.trim(),
      email: f.email.value.trim(),
      total: total,
      status: "confirmed",
      createdAt: Date.now()
    };
    store.set(KEY_CONTACT, { name: b.name, email: b.email });
    saveBookings([b].concat(bookings()));
    var title = tx(current.title);
    closeModal();
    toast(t("booked") + " — " + title, page === "account" ? null : { href: "compte.html", label: t("see") });
    if (page === "account") renderAccount();
  });
  $$("[data-close]", modal).forEach(function (el) { el.addEventListener("click", closeModal); });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && modal.classList.contains("is-open")) closeModal();
    // Piège du focus dans la modale
    if (e.key === "Tab" && modal.classList.contains("is-open")) {
      var els = $$("button, input, a[href]", modal).filter(function (x) { return x.offsetParent !== null; });
      var first = els[0], last = els[els.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });
  document.addEventListener("click", function (e) {
    var btn = e.target.closest && e.target.closest("[data-book]");
    if (btn) openModal(offerById(btn.getAttribute("data-book")));
  });

  /* ==========================================================================
     Accueil
     ========================================================================== */
  var homeBound = false;
  function renderHome() {
    var grid = $("[data-destinations]");
    grid.innerHTML = D.destinations.map(function (d, i) {
      var n = D.offers.filter(function (o) { return o.dest === d.key; }).length;
      return '<a href="hotels.html?q=' + encodeURIComponent(tx(d.name)) + '" class="destination_card' + (i === 0 ? " is-featured" : "") + '">' +
        '<img src="images/' + d.image + '.webp" alt="" loading="lazy" class="destination_image">' +
        '<div class="destination_content"><div><p class="text-style-eyebrow" style="opacity:.8">' + esc(tx(d.country)) + '</p><p class="destination_name">' + esc(tx(d.name)) + "</p></div>" +
        '<span class="destination_count">' + n + " " + t("offersCount") + "</span></div></a>";
    }).join("");
    $("[data-featured]").innerHTML = D.featured.map(function (id) { return offerCard(offerById(id)); }).join("");
    $("[data-dest-list]").innerHTML = D.destinations.map(function (d) { return '<option value="' + esc(tx(d.name)) + '">'; }).join("");
    var active = $(".search_tab.is-active");
    $("[data-search-where]").placeholder = t(active.getAttribute("data-where"));

    if (homeBound) return;
    homeBound = true;
    var sform = $("[data-search-form]");
    sform.elements.from.min = today;
    sform.elements.to.min = addDays(today, 1);
    sform.elements.from.addEventListener("change", function () {
      var f = sform.elements;
      f.to.min = addDays(f.from.value || today, 1);
      if (f.to.value && f.to.value <= f.from.value) f.to.value = addDays(f.from.value, 1);
    });
    $$(".search_tab").forEach(function (tab) {
      tab.addEventListener("click", function () {
        $$(".search_tab").forEach(function (x) { x.classList.remove("is-active"); x.setAttribute("aria-selected", "false"); });
        tab.classList.add("is-active"); tab.setAttribute("aria-selected", "true");
        var where = tab.getAttribute("data-where");
        var input = $("[data-search-where]");
        input.setAttribute("data-i18n-ph", where);
        input.placeholder = t(where);
        sform.action = catPage(tab.getAttribute("data-tab"));
      });
    });
    sform.addEventListener("submit", function (e) {
      e.preventDefault();
      var f = sform.elements, p = [];
      ["q", "from", "to", "guests"].forEach(function (k) { if (f[k].value) p.push(k + "=" + encodeURIComponent(f[k].value)); });
      location.href = catPage($(".search_tab.is-active").getAttribute("data-tab")) + (p.length ? "?" + p.join("&") : "");
    });
    $("[data-newsletter]").addEventListener("submit", function (e) {
      e.preventDefault();
      e.target.reset();
      toast(t("ctaDone"));
    });
  }

  /* ==========================================================================
     Listes (hôtels, voitures, billets, excursions)
     ========================================================================== */
  var filters = { zone: "all", q: "", sort: "reco" }, listingBound = false;
  function matches(o, q) {
    if (!q) return true;
    var hay = [o.dest];
    LANGS.forEach(function (l) { hay.push(o.title[l], o.place[l]); o.tags.forEach(function (g) { hay.push(g[l]); }); });
    var h = norm(hay.join(" "));
    return norm(q).split(/\s+/).filter(Boolean).every(function (w) { return h.indexOf(w) > -1; });
  }
  function renderListing(cat) {
    var meta = D.categories[cat];
    $$("[data-i18n-cat]").forEach(function (el) { el.textContent = tx(meta[el.getAttribute("data-i18n-cat")]); });
    document.title = tx(meta.label) + " — Seyyora";

    if (!listingBound) {
      listingBound = true;
      var params = new URLSearchParams(location.search);
      filters.q = params.get("q") || "";
      prefill = { from: params.get("from") || "", to: params.get("to") || "", guests: params.get("guests") || "" };
      var qInput = $("[data-filter-q]");
      qInput.value = filters.q;
      qInput.addEventListener("input", function () { filters.q = qInput.value; renderListing(cat); });
      $("[data-filter-sort]").addEventListener("change", function (e) { filters.sort = e.target.value; renderListing(cat); });
      $$(".filters_chip").forEach(function (c) {
        c.addEventListener("click", function () { filters.zone = c.getAttribute("data-zone"); renderListing(cat); });
      });
      $("[data-reset]").addEventListener("click", function () {
        filters = { zone: "all", q: "", sort: "reco" };
        qInput.value = ""; $("[data-filter-sort]").value = "reco";
        history.replaceState(null, "", location.pathname);
        renderListing(cat);
      });
    }
    $$(".filters_chip").forEach(function (c) { c.classList.toggle("is-active", c.getAttribute("data-zone") === filters.zone); c.setAttribute("aria-pressed", c.getAttribute("data-zone") === filters.zone); });

    var list = D.offers.filter(function (o) { return o.category === cat && (filters.zone === "all" || o.zone === filters.zone) && matches(o, filters.q); });
    var sorters = {
      "price-asc": function (a, b) { return a.price - b.price; },
      "price-desc": function (a, b) { return b.price - a.price; },
      "rating": function (a, b) { return b.rating - a.rating; }
    };
    if (sorters[filters.sort]) list.sort(sorters[filters.sort]);
    $("[data-listing]").innerHTML = list.map(offerCard).join("");
    $("[data-result-count]").textContent = list.length + " " + t("results");
    $("[data-empty]").classList.toggle("hide", list.length > 0);
    observeReveal();
  }

  /* ==========================================================================
     Mon compte
     ========================================================================== */
  var accountBound = false;
  function renderAccount() {
    var list = bookings().sort(function (a, b) { return b.createdAt - a.createdAt; });
    var active = list.filter(function (b) { return b.status === "confirmed"; });
    var contact = store.get(KEY_CONTACT, {});
    var first = (contact.name || "").split(" ")[0];
    $("[data-account-hello]").textContent = t("hello") + (first ? ", " + first : "") + " 👋";
    $("[data-stat-active]").textContent = active.length;
    $("[data-stat-total]").textContent = list.length;
    $("[data-stat-spent]").textContent = price(active.reduce(function (s, b) { return s + (b.total || 0); }, 0));
    $("[data-bookings-empty]").classList.toggle("hide", list.length > 0);
    $("[data-clear-all]").classList.toggle("hide", list.length === 0);

    $("[data-bookings]").innerHTML = list.map(function (b) {
      var o = offerById(b.offerId);
      if (!o) return "";
      var off = b.status !== "confirmed";
      return '<article class="booking_card' + (off ? " is-cancelled" : "") + '">' +
        '<img src="images/' + o.image + '.webp" alt="" class="booking_image" loading="lazy">' +
        '<div class="booking_content">' +
        '<div class="booking_top"><div><p class="text-style-eyebrow text-color-primary">' + esc(tx(o.place)) + '</p><h3 class="heading-style-h4 margin-top margin-tiny">' + esc(tx(o.title)) + '</h3><p class="booking_ref margin-top margin-tiny">' + esc(b.ref) + "</p></div>" +
        '<span class="badge' + (off ? " is-muted" : "") + '">' + t(off ? "cancelled" : "confirmed") + "</span></div>" +
        '<div class="booking_meta">' +
        '<span class="booking_meta-item">' + icon("calendar", "is-small") + fmtDate(b.start) + (b.end ? " → " + fmtDate(b.end) : "") + "</span>" +
        '<span class="booking_meta-item">' + icon("users", "is-small") + b.guests + "</span>" +
        '<span class="booking_meta-item text-style-display text-weight-bold" style="color:var(--foreground)">' + price(b.total) + "</span></div>" +
        '<div style="display:flex;gap:.5rem;flex-wrap:wrap">' +
        (off
          ? '<button type="button" class="button is-danger is-small" data-delete="' + b.id + '">' + icon("trash", "is-small") + t("delete") + "</button>"
          : '<button type="button" class="button is-ghost is-small" data-cancel="' + b.id + '">' + icon("ban", "is-small") + t("cancel") + "</button>") +
        "</div></div></article>";
    }).join("");

    if (accountBound) return;
    accountBound = true;
    $("[data-bookings]").addEventListener("click", function (e) {
      var c = e.target.closest("[data-cancel]"), d = e.target.closest("[data-delete]");
      if (c) {
        saveBookings(bookings().map(function (b) { if (b.id === c.getAttribute("data-cancel")) b.status = "cancelled"; return b; }));
        toast(t("cancelledToast"));
      } else if (d) {
        saveBookings(bookings().filter(function (b) { return b.id !== d.getAttribute("data-delete"); }));
        toast(t("deletedToast"));
      } else return;
      renderAccount();
    });
    $("[data-clear-all]").addEventListener("click", function () { saveBookings([]); renderAccount(); });
  }

  /* ---------- Routage par page ---------- */
  function renderPage() {
    if (page === "home") renderHome();
    else if (page.indexOf("listing:") === 0) renderListing(page.split(":")[1]);
    else if (page === "account") renderAccount();
    updateCount();
    observeReveal();
  }

  // Synchronise le compteur si une autre fenêtre modifie les réservations
  window.addEventListener("storage", function (e) { if (e.key === KEY_BOOKINGS) { updateCount(); if (page === "account") renderAccount(); } });

  applyI18n();
})();
