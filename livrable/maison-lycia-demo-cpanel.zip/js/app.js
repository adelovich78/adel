/* ==========================================================================
   Maison Lycia — logique de la démo statique (aucun backend)
   ========================================================================== */
(function () {
  "use strict";

  var D = window.LYCIA;
  var LANGS = ["en", "tr", "fr"];
  var KEY_LANG = "lycia_lang";
  var page = document.body.getAttribute("data-page") || "";
  var lang = document.documentElement.lang;
  if (LANGS.indexOf(lang) < 0) lang = "fr";

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var t = function (k) { return (D.i18n[k] && D.i18n[k][lang]) || k; };
  var esc = function (s) { return String(s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var locale = function () { return { en: "en-GB", tr: "tr-TR", fr: "fr-FR" }[lang]; };
  var eur = function (n) { return new Intl.NumberFormat(locale(), { maximumFractionDigits: 0 }).format(n) + " €"; };
  var roomById = function (id) { return D.rooms.filter(function (r) { return r.id === id; })[0]; };
  var spaById = function (id) { return D.spa.filter(function (s) { return s.id === id; })[0]; };

  // Dates locales AAAA-MM-JJ
  var iso = function (d) { var z = function (n) { return (n < 10 ? "0" : "") + n; }; return d.getFullYear() + "-" + z(d.getMonth() + 1) + "-" + z(d.getDate()); };
  var addDays = function (s, n) { var d = new Date(s + "T00:00:00"); d.setDate(d.getDate() + n); return iso(d); };
  var diffDays = function (a, b) { return Math.round((new Date(b + "T00:00:00") - new Date(a + "T00:00:00")) / 86400000); };
  var today = iso(new Date());

  /* ---------- i18n ---------- */
  function applyI18n() {
    document.documentElement.lang = lang;
    $$("[data-i18n]").forEach(function (el) { el.textContent = t(el.getAttribute("data-i18n")); });
    $$(".lang_button").forEach(function (b) { var on = b.getAttribute("data-lang") === lang; b.classList.toggle("is-active", on); b.setAttribute("aria-pressed", on); });
    if (page === "contact") updateSummary();
    if (page === "rooms" && lastAdvice) renderAdvice(lastAdvice, false);
  }
  $$(".lang_button").forEach(function (b) {
    b.addEventListener("click", function () { lang = b.getAttribute("data-lang"); try { localStorage.setItem(KEY_LANG, lang); } catch (e) {} applyI18n(); });
  });

  /* ---------- Navbar : transparente sur le hero de l'accueil ---------- */
  var nav = $("[data-navbar]"), menuBtn = $(".navbar_menu-button"), mobile = $(".navbar_mobile");
  var transparent = nav.hasAttribute("data-transparent");
  function syncNav() {
    var open = mobile.classList.contains("is-open");
    nav.classList.toggle("is-solid", !transparent || open || window.scrollY > 40);
  }
  window.addEventListener("scroll", syncNav, { passive: true });
  menuBtn.addEventListener("click", function () {
    var open = mobile.classList.toggle("is-open");
    menuBtn.setAttribute("aria-expanded", open);
    syncNav();
  });
  syncNav();

  /* ---------- Apparition au scroll ---------- */
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add("is-visible"); io.unobserve(e.target); } });
    }, { rootMargin: "0px 0px -10% 0px" });
    $$(".reveal").forEach(function (el) { io.observe(el); });
  } else {
    $$(".reveal").forEach(function (el) { el.classList.add("is-visible"); });
  }

  /* ---------- Accueil : barre de réservation ---------- */
  var bar = $("[data-booking-bar]");
  if (bar) {
    var f = bar.elements;
    f.arrive.min = today;
    f.arrive.value = addDays(today, 30);
    f.depart.min = addDays(f.arrive.value, 1);
    f.depart.value = addDays(f.arrive.value, 5);
    f.arrive.addEventListener("change", function () {
      f.depart.min = addDays(f.arrive.value || today, 1);
      if (!f.depart.value || f.depart.value <= f.arrive.value) f.depart.value = addDays(f.arrive.value, 1);
    });
    bar.addEventListener("submit", function (e) {
      e.preventDefault();
      location.href = "contact.html?arrive=" + f.arrive.value + "&depart=" + f.depart.value + "&guests=" + f.guests.value;
    });
  }

  /* ==========================================================================
     Conseiller séjour (règles locales, sans IA ni serveur)
     ========================================================================== */
  var ADV = {
    reason: {
      deluxe: { en: "Perfect for one or two: a private balcony on the open sea and the best value of the resort.", tr: "Bir veya iki kişi için ideal: açık denize bakan özel balkon ve otelin en iyi fiyatı.", fr: "Idéale à un ou deux : un balcon privé face au large et le meilleur rapport qualité-prix de l'hôtel." },
      garden: { en: "Space and calm among the olive trees, with a separate living room for up to three guests.", tr: "Zeytin ağaçları arasında ferahlık ve sakinlik, üç kişiye kadar ayrı oturma odası.", fr: "De l'espace et du calme parmi les oliviers, avec un salon séparé pour trois personnes." },
      villa: { en: "Your own infinity pool steps from the sand, total privacy and a butler at your service.", tr: "Kumlara birkaç adım uzaklıkta size özel sonsuzluk havuzu, tam mahremiyet ve butler hizmeti.", fr: "Votre piscine à débordement à deux pas du sable, une intimité totale et un majordome à votre service." },
      penthouse: { en: "The resort's crown: a rooftop terrace with 360° views from the Taurus to the sea.", tr: "Otelin tacı: Toros'tan denize 360° manzaralı çatı terası.", fr: "Le joyau de l'hôtel : une terrasse sur le toit avec une vue à 360° du Taurus à la mer." }
    },
    combo: { en: "For {n} guests we suggest two adjoining Lycian Beach Villas.", tr: "{n} kişi için yan yana iki Likya Plaj Villası öneriyoruz.", fr: "Pour {n} voyageurs, nous vous suggérons deux villas lyciennes attenantes." },
    extra: {
      honeymoon: { en: "To complete it: the Couples' Ritual at the spa and dinner at Saray.", tr: "Tamamlamak için: spada Çiftler Ritüeli ve Saray'da akşam yemeği.", fr: "Pour compléter : le Rituel en duo au spa et un dîner chez Saray." },
      family: { en: "Children love long lunches at Olea, under the pines.", tr: "Çocuklar Olea'da, çam ağaçları altındaki uzun öğle yemeklerini çok sever.", fr: "Les enfants adorent les longs déjeuners chez Olea, à l'ombre des pins." },
      other: { en: "Don't miss a traditional hammam ritual and sunset at Mavi.", tr: "Geleneksel hamam ritüelini ve Mavi'de gün batımını kaçırmayın.", fr: "Ne manquez pas le hammam traditionnel et le coucher du soleil chez Mavi." }
    }
  };
  var lastAdvice = null;

  function advise(guests, w) {
    var id;
    if (guests > 6) id = "villa";
    else if (w.view) id = "penthouse";
    else if (w.pool || (w.honeymoon && !w.budget) || guests >= 4) id = "villa";
    else if (guests === 3 || w.family || w.quiet) id = "garden";
    else id = "deluxe";
    return { id: id, guests: guests, combo: guests > 6, extra: w.honeymoon ? "honeymoon" : (w.family || guests >= 3) ? "family" : "other" };
  }

  function renderAdvice(a, animate) {
    var r = roomById(a.id), box = $("[data-advisor-result]");
    var price = r.price ? t("from") + " " + eur(r.price * (a.combo ? 2 : 1)) + " " + t("perNight") : t("onRequest");
    box.innerHTML =
      '<img src="images/' + r.image + '.webp" alt="" class="advisor_result-image">' +
      '<p class="text-style-eyebrow text-color-accent">' + esc(t("adv.result")) + "</p>" +
      '<h3 class="heading-style-h4 margin-top margin-xsmall">' + esc(t("room." + r.id + ".name")) + (a.combo ? " × 2" : "") + "</h3>" +
      '<p class="text-color-muted margin-top margin-xsmall">' + esc(a.combo ? ADV.combo[lang].replace("{n}", a.guests) : ADV.reason[r.id][lang]) + "</p>" +
      '<p class="text-style-italic margin-top margin-xsmall" style="font-family:var(--font-serif);font-size:1.2rem">' + esc(ADV.extra[a.extra][lang]) + "</p>" +
      '<div class="room_footer" style="padding-top:1.5rem"><span class="text-style-eyebrow text-color-accent">' + esc(price) + "</span>" +
      '<a class="button" href="contact.html?room=' + r.id + "&guests=" + a.guests + '">' + esc(t("adv.book")) + "</a></div>" +
      '<p class="text-size-small text-color-muted margin-top margin-small" style="border-top:1px solid var(--border);padding-top:1rem">' + esc(t("adv.demo")) + "</p>";
    if (animate) { box.classList.remove("is-updated"); void box.offsetWidth; box.classList.add("is-updated"); }
  }

  var advForm = $("[data-advisor]");
  if (advForm) {
    $$(".advisor_chip", advForm).forEach(function (c) {
      c.addEventListener("click", function () { var on = c.classList.toggle("is-active"); c.setAttribute("aria-pressed", on); });
    });
    advForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var g = Math.max(1, Math.min(12, parseInt(advForm.elements.guests.value, 10) || 1));
      advForm.elements.guests.value = g;
      var w = {};
      $$(".advisor_chip.is-active", advForm).forEach(function (c) { w[c.getAttribute("data-wish")] = true; });
      lastAdvice = advise(g, w);
      renderAdvice(lastAdvice, true);
    });
  }

  /* ==========================================================================
     Contact : demande de séjour avec estimation
     ========================================================================== */
  var cform = $("[data-contact-form]");
  function updateSummary() {
    if (!cform) return;
    var f = cform.elements, box = $("[data-summary]");
    var r = roomById(f.room.value), s = spaById(f.treatment.value);
    var nights = f.arrive.value && f.depart.value ? diffDays(f.arrive.value, f.depart.value) : 0;
    if (!r || nights < 1) {
      box.innerHTML = '<p class="text-color-muted">' + esc(t("form.pick")) + "</p>" + (s ? line(t("spa." + s.id + ".name"), eur(s.price)) : "");
      return;
    }
    var html = "", total = 0;
    if (r.price) {
      html += line(t("room." + r.id + ".name") + " · " + nights + " " + t(nights > 1 ? "form.nights" : "form.night"), eur(r.price * nights));
      total += r.price * nights;
    } else {
      html += line(t("room." + r.id + ".name"), t("form.onReq"));
    }
    if (s) { html += line(t("spa." + s.id + ".name"), eur(s.price)); total += s.price; }
    html += '<div class="summary_line summary_total"><span>' + esc(t("form.estimate")) + "</span><span>" + (r.price ? eur(total) : esc(t("form.onReq"))) + "</span></div>";
    box.innerHTML = html;
  }
  function line(a, b) { return '<div class="summary_line text-color-muted"><span>' + esc(a) + "</span><span>" + esc(b) + "</span></div>"; }

  if (cform) {
    var f2 = cform.elements, p = new URLSearchParams(location.search);
    f2.arrive.min = today;
    f2.arrive.value = p.get("arrive") && p.get("arrive") >= today ? p.get("arrive") : addDays(today, 30);
    f2.depart.min = addDays(f2.arrive.value, 1);
    f2.depart.value = p.get("depart") && p.get("depart") > f2.arrive.value ? p.get("depart") : addDays(f2.arrive.value, 5);
    if (p.get("guests")) f2.guests.value = Math.max(1, Math.min(12, parseInt(p.get("guests"), 10) || 2));
    if (roomById(p.get("room"))) f2.room.value = p.get("room");
    else if (!p.get("treatment") && p.get("arrive")) f2.room.value = "deluxe";
    if (spaById(p.get("treatment"))) f2.treatment.value = p.get("treatment");

    cform.addEventListener("input", function (e) {
      if (e.target === f2.arrive && f2.arrive.value) {
        f2.depart.min = addDays(f2.arrive.value, 1);
        if (!f2.depart.value || f2.depart.value <= f2.arrive.value) f2.depart.value = addDays(f2.arrive.value, 1);
      }
      updateSummary();
    });
    cform.addEventListener("change", updateSummary);
    cform.addEventListener("submit", function (e) {
      e.preventDefault();
      if (!cform.reportValidity()) return;
      $("[data-confirm-ref]").textContent = "ML-" + Math.random().toString(36).slice(2, 8).toUpperCase();
      cform.classList.add("hide");
      $("[data-confirm]").classList.remove("hide");
      $("[data-confirm]").scrollIntoView({ behavior: "smooth", block: "center" });
    });
    $("[data-confirm-again]").addEventListener("click", function () {
      $("[data-confirm]").classList.add("hide");
      cform.classList.remove("hide");
      f2.msg.value = "";
    });
  }

  applyI18n();
})();
