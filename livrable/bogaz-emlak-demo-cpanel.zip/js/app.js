/* ==========================================================================
   Boğaz Emlak — logique de la démo statique (aucun backend)
   ========================================================================== */
(function () {
  "use strict";

  var D = window.BOGAZ;
  var LANGS = ["tr", "en", "fr"];
  var lang = document.documentElement.lang;
  if (LANGS.indexOf(lang) < 0) lang = "fr";

  var store = {
    get: function (k, f) { try { var v = localStorage.getItem(k); return v === null ? f : JSON.parse(v); } catch (e) { return f; } },
    set: function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  };
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var t = function (k) { return (D.i18n[k] && D.i18n[k][lang]) || k; };
  var esc = function (s) { return String(s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var icon = function (n, c) { return '<svg class="icon ' + (c || "") + '" viewBox="0 0 24 24" aria-hidden="true">' + D.icons[n] + "</svg>"; };
  var locale = function () { return { tr: "tr-TR", en: "en-GB", fr: "fr-FR" }[lang]; };
  var byId = function (id) { return D.listings.filter(function (l) { return l.id === id; })[0]; };

  /* ---------- État ---------- */
  var state = { deal: "", area: "", type: "", rooms: 0, sort: "reco", favOnly: false, cur: store.get("bogaz_cur", "TRY") };
  var favs = store.get("bogaz_favs", []);
  if (!Array.isArray(favs)) favs = [];
  if (!D.rates[state.cur]) state.cur = "TRY";

  /* ---------- Prix dans la devise choisie (taux indicatifs) ---------- */
  function money(tryValue) {
    var v = tryValue * D.rates[state.cur];
    var opts = { style: "currency", currency: state.cur, currencyDisplay: "narrowSymbol", maximumFractionDigits: 0 };
    if (state.cur !== "TRY" && v >= 1e6) { opts.notation = "compact"; opts.maximumFractionDigits = 1; }
    return (state.cur !== "TRY" ? "≈ " : "") + new Intl.NumberFormat(locale(), opts).format(v);
  }
  function price(l) { return money(l.price) + (l.deal === "rent" ? " " + t("l.month") : ""); }

  /* ---------- Toast ---------- */
  function toast(msg) {
    var el = document.createElement("div");
    el.className = "toast_item";
    el.innerHTML = icon("check") + "<span>" + esc(msg) + "</span>";
    $(".toast_wrapper").appendChild(el);
    setTimeout(function () { el.classList.add("is-leaving"); setTimeout(function () { el.remove(); }, 220); }, 3800);
  }

  /* ==========================================================================
     Annonces
     ========================================================================== */
  function card(l) {
    var fav = favs.indexOf(l.id) > -1;
    return '<article class="listing_card reveal">' +
      '<button type="button" class="fav_button' + (fav ? " is-active" : "") + '" data-fav="' + l.id + '" aria-pressed="' + fav + '" aria-label="' + esc(t("fav.add")) + '">' + icon("heart") + "</button>" +
      '<button type="button" class="listing_media" data-open="' + l.id + '" aria-label="' + esc(t("t." + l.id)) + '">' +
      '<img src="images/' + l.img + '.webp" alt="" loading="lazy" width="1024" height="768" class="listing_image">' +
      '<span class="listing_badge' + (l.deal === "rent" ? " is-rent" : "") + '">' + esc(t(l.deal === "rent" ? "f.rent" : "f.sale")) + "</span></button>" +
      '<div class="listing_content"><div class="listing_body"><p class="listing_loc">' + esc(l.loc) + '</p><h3 class="listing_title">' + esc(t("t." + l.id)) + "</h3></div>" +
      '<div class="listing_footer"><span class="text-color-muted">' + l.rooms + " · " + l.m2 + ' m²</span><span class="listing_price">' + esc(price(l)) + "</span></div>" +
      '<button type="button" class="button is-outline is-small margin-top margin-small" data-open="' + l.id + '">' + esc(t("l.details")) + "</button>" +
      "</div></article>";
  }

  function filtered() {
    var list = D.listings.filter(function (l) {
      return (!state.deal || l.deal === state.deal) && (!state.area || l.area === state.area) && (!state.type || l.type === state.type) &&
        (!state.rooms || parseInt(l.rooms, 10) >= state.rooms) && (!state.favOnly || favs.indexOf(l.id) > -1);
    });
    var s = { asc: function (a, b) { return a.price - b.price; }, desc: function (a, b) { return b.price - a.price; }, size: function (a, b) { return b.m2 - a.m2; } }[state.sort];
    return s ? list.sort(s) : list;
  }

  function renderListings() {
    var list = filtered();
    $("[data-listings]").innerHTML = list.map(card).join("");
    $("[data-empty]").classList.toggle("hide", list.length > 0);
    var tags = [state.area, state.type ? t("type." + state.type) : "", state.rooms ? state.rooms + "+ " + t("l.rooms").toLowerCase() : ""].filter(Boolean);
    $("[data-results]").textContent = list.length + " " + t("l.results") + (tags.length ? " · " + tags.join(" · ") : "") + (state.cur !== "TRY" ? " · " + t("l.approx") : "");
    $$("[data-deal-filter]").forEach(function (c) { var on = c.getAttribute("data-deal-filter") === state.deal && !state.favOnly; c.classList.toggle("is-active", on); c.setAttribute("aria-pressed", on); });
    var fb = $("[data-fav-filter]"); fb.classList.toggle("is-active", state.favOnly); fb.setAttribute("aria-pressed", state.favOnly);
    $("[data-fav-count]").textContent = favs.length ? favs.length : "";
    $$(".currency_button").forEach(function (b) { b.classList.toggle("is-active", b.getAttribute("data-cur") === state.cur); });
    observeReveal();
  }

  function renderAreas() {
    $$("[data-area-count]").forEach(function (el) {
      var a = el.getAttribute("data-area-count");
      el.textContent = D.listings.filter(function (l) { return l.area === a; }).length + " " + t("l.results");
    });
  }

  // Formulaire de recherche du hero -> filtre la liste et défile jusqu'aux annonces
  var search = $("[data-search]"), heroDeal = "sale";
  $$(".search_deal-button").forEach(function (b) {
    b.addEventListener("click", function () {
      heroDeal = b.getAttribute("data-deal");
      $$(".search_deal-button").forEach(function (x) { x.classList.toggle("is-active", x === b); });
    });
  });
  search.addEventListener("submit", function (e) {
    e.preventDefault();
    var f = search.elements;
    state.deal = heroDeal; state.area = f.area.value; state.type = f.type.value; state.rooms = parseInt(f.rooms.value, 10) || 0; state.favOnly = false;
    renderListings();
    $("#ilanlar").scrollIntoView({ behavior: "smooth" });
  });

  $$("[data-deal-filter]").forEach(function (c) {
    c.addEventListener("click", function () { state.deal = c.getAttribute("data-deal-filter"); state.favOnly = false; renderListings(); });
  });
  $("[data-fav-filter]").addEventListener("click", function () { state.favOnly = !state.favOnly; renderListings(); });
  $("[data-sort]").addEventListener("change", function (e) { state.sort = e.target.value; renderListings(); });
  $$(".currency_button").forEach(function (b) {
    b.addEventListener("click", function () { state.cur = b.getAttribute("data-cur"); store.set("bogaz_cur", state.cur); renderListings(); });
  });
  $("[data-reset]").addEventListener("click", function () {
    state.deal = ""; state.area = ""; state.type = ""; state.rooms = 0; state.favOnly = false;
    search.reset(); renderListings();
  });
  $$("[data-area]").forEach(function (a) {
    a.addEventListener("click", function () {
      state.area = a.getAttribute("data-area"); state.deal = ""; state.type = ""; state.rooms = 0; state.favOnly = false;
      search.elements.area.value = state.area;
      renderListings();
      $("#ilanlar").scrollIntoView({ behavior: "smooth" });
    });
  });

  /* ---------- Favoris + ouverture de fiche (délégation) ---------- */
  document.addEventListener("click", function (e) {
    var fav = e.target.closest("[data-fav]");
    if (fav) {
      var id = fav.getAttribute("data-fav"), i = favs.indexOf(id);
      if (i > -1) favs.splice(i, 1); else favs.push(id);
      store.set("bogaz_favs", favs);
      if (fav.closest(".modal_component")) { fav.classList.toggle("is-active", i < 0); fav.setAttribute("aria-pressed", i < 0); }
      renderListings();
      return;
    }
    var open = e.target.closest("[data-open]");
    if (open) openModal(byId(open.getAttribute("data-open")));
  });

  /* ==========================================================================
     Fiche détaillée (modale)
     ========================================================================== */
  var modal = $("#listing-modal"), lastFocus = null, current = null;
  function renderModal() {
    var l = current, fav = favs.indexOf(l.id) > -1;
    var spec = function (k, v) { return '<div class="detail_spec"><div class="text-size-tiny text-color-muted">' + esc(t(k)) + '</div><div class="detail_spec-value">' + esc(v) + "</div></div>"; };
    var perM2 = l.deal === "sale" ? '<p class="text-size-small text-color-muted margin-top margin-xsmall">' + esc(money(Math.round(l.price / l.m2))) + " " + esc(t("l.perM2")) + "</p>" : "";
    $("[data-modal-body]").innerHTML =
      '<div class="detail_component">' +
      '<div style="position:relative"><img src="images/' + l.img + '.webp" alt="" class="detail_image"><span class="listing_badge' + (l.deal === "rent" ? " is-rent" : "") + '">' + esc(t(l.deal === "rent" ? "f.rent" : "f.sale")) + "</span></div>" +
      '<div class="detail_content">' +
      '<div><p class="listing_loc">' + esc(l.loc) + " · " + esc(t("l.ref")) + " " + l.id + '</p><h2 class="heading-style-h3 margin-top margin-xsmall" id="modal-title">' + esc(t("t." + l.id)) + "</h2></div>" +
      '<div><p class="detail_price">' + esc(price(l)) + "</p>" + perM2 + "</div>" +
      '<div class="detail_specs">' + spec("l.rooms", l.rooms) + spec("l.size", l.m2 + " m²") + spec("l.type", t("type." + l.type)) + spec("l.status", t(l.deal === "rent" ? "f.rent" : "f.sale")) + "</div>" +
      '<div><p class="form_label">' + esc(t("l.features")) + '</p><div class="detail_features margin-top margin-xsmall">' + l.ft.map(function (f) { return '<span class="detail_feature">' + icon("check") + esc(t("ft." + f)) + "</span>"; }).join("") + "</div></div>" +
      '<div style="display:flex;gap:.5rem;margin-top:auto">' +
      '<button type="button" class="button is-accent" style="flex:1" data-interest="' + l.id + '">' + esc(t("l.interested")) + "</button>" +
      '<button type="button" class="fav_button' + (fav ? " is-active" : "") + '" style="position:static;box-shadow:inset 0 0 0 1px var(--border);width:3rem;height:3rem" data-fav="' + l.id + '" aria-pressed="' + fav + '" aria-label="' + esc(t("fav.add")) + '">' + icon("heart") + "</button>" +
      "</div></div></div>";
    $("[data-interest]").addEventListener("click", function () { setAbout(l); closeModal(); $("#iletisim").scrollIntoView({ behavior: "smooth" }); setTimeout(function () { $("[data-contact] [name=name]").focus({ preventScroll: true }); }, 600); });
  }
  function openModal(l) {
    if (!l) return;
    current = l; lastFocus = document.activeElement;
    renderModal();
    modal.classList.add("is-open"); modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("is-locked");
    setTimeout(function () { $(".modal_close", modal).focus(); }, 50);
  }
  function closeModal() {
    modal.classList.remove("is-open"); modal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("is-locked");
    current = null;
    if (lastFocus) lastFocus.focus({ preventScroll: true });
  }
  $$("[data-close]", modal).forEach(function (el) { el.addEventListener("click", closeModal); });
  document.addEventListener("keydown", function (e) {
    if (!modal.classList.contains("is-open")) return;
    if (e.key === "Escape") closeModal();
    if (e.key === "Tab") {
      var els = $$("button, a[href]", modal), first = els[0], last = els[els.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });

  /* ==========================================================================
     Contact
     ========================================================================== */
  var contact = $("[data-contact]"), aboutId = null;
  function setAbout(l) {
    aboutId = l ? l.id : null;
    $("[data-about]").classList.toggle("hide", !l);
    if (l) {
      $("[data-about-text]").textContent = t("t." + l.id) + " — " + l.loc + " (" + l.id + ")";
      contact.elements.interest.value = l.deal === "rent" ? "rentI" : "buy";
    }
  }
  $("[data-about-clear]").addEventListener("click", function () { setAbout(null); });
  contact.addEventListener("submit", function (e) {
    e.preventDefault();
    if (!contact.reportValidity()) return;
    contact.reset(); setAbout(null);
    toast(t("c.thanks"));
  });

  /* ==========================================================================
     Calculateur de crédit (mensualité constante)
     ========================================================================== */
  var calc = $("[data-calc]");
  function tl(n) { return new Intl.NumberFormat(locale(), { style: "currency", currency: "TRY", currencyDisplay: "narrowSymbol", maximumFractionDigits: 0 }).format(n); }
  function updateCalc() {
    var f = calc.elements;
    var p = Math.max(0, parseFloat(f.price.value) || 0);
    var down = parseInt(f.down.value, 10) / 100;
    var n = parseInt(f.years.value, 10) * 12;
    var r = Math.max(0, parseFloat(f.rate.value) || 0) / 100;
    var loan = p * (1 - down);
    var m = r ? loan * r / (1 - Math.pow(1 + r, -n)) : loan / n;
    $("[data-down-out]").textContent = Math.round(down * 100) + " %";
    $("[data-calc-monthly]").textContent = tl(m);
    $("[data-calc-loan]").textContent = tl(loan);
    $("[data-calc-total]").textContent = tl(m * n);
  }
  calc.addEventListener("input", updateCalc);
  calc.addEventListener("submit", function (e) { e.preventDefault(); });

  /* ==========================================================================
     Navigation, langue, animations
     ========================================================================== */
  var nav = $("[data-navbar]"), menuBtn = $(".navbar_menu-button"), mobile = $(".navbar_mobile");
  function syncNav() { nav.classList.toggle("is-solid", window.scrollY > 60 || mobile.classList.contains("is-open")); }
  window.addEventListener("scroll", syncNav, { passive: true });
  menuBtn.addEventListener("click", function () { var o = mobile.classList.toggle("is-open"); menuBtn.setAttribute("aria-expanded", o); syncNav(); });
  $$(".navbar_mobile a").forEach(function (a) { a.addEventListener("click", function () { mobile.classList.remove("is-open"); menuBtn.setAttribute("aria-expanded", "false"); syncNav(); }); });
  syncNav();

  // Lien actif selon la section visible
  var links = $$(".navbar_menu .navbar_link");
  if ("IntersectionObserver" in window) {
    var spy = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) links.forEach(function (a) { a.classList.toggle("is-current", a.getAttribute("href") === "#" + e.target.id); });
      });
    }, { rootMargin: "-45% 0px -50% 0px" });
    ["ilanlar", "bolgeler", "hizmetler", "iletisim"].forEach(function (id) { spy.observe(document.getElementById(id)); });
  }

  var io = "IntersectionObserver" in window ? new IntersectionObserver(function (entries) {
    entries.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add("is-visible"); io.unobserve(e.target); } });
  }, { rootMargin: "0px 0px -8% 0px" }) : null;
  function observeReveal() {
    $$(".reveal:not(.is-visible)").forEach(function (el, i) {
      if (!io) { el.classList.add("is-visible"); return; }
      el.style.transitionDelay = (el.classList.contains("listing_card") ? (i % 3) * 80 : 0) + "ms";
      io.observe(el);
    });
  }

  // Compteurs animés des chiffres clés
  var counted = false;
  function animateCounters() {
    if (counted) return; counted = true;
    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    $$("[data-count]").forEach(function (el) {
      var target = parseInt(el.getAttribute("data-count"), 10), suffix = el.getAttribute("data-suffix") || "", start = null;
      var fmt = function (v) { return new Intl.NumberFormat(locale()).format(v) + suffix; };
      if (reduce) { el.textContent = fmt(target); return; }
      function step(ts) {
        if (!start) start = ts;
        var p = Math.min(1, (ts - start) / 1400), eased = 1 - Math.pow(1 - p, 3);
        el.textContent = fmt(Math.round(target * eased));
        if (p < 1) requestAnimationFrame(step);
      }
      requestAnimationFrame(step);
    });
  }
  if ("IntersectionObserver" in window) {
    var co = new IntersectionObserver(function (e) { if (e[0].isIntersecting) { animateCounters(); co.disconnect(); } });
    co.observe($(".stats_component"));
  } else animateCounters();

  function applyI18n() {
    document.documentElement.lang = lang;
    $$("[data-i18n]").forEach(function (el) { el.textContent = t(el.getAttribute("data-i18n")); });
    $$(".lang_button").forEach(function (b) { var on = b.getAttribute("data-lang") === lang; b.classList.toggle("is-active", on); b.setAttribute("aria-pressed", on); });
    if (counted) $$("[data-count]").forEach(function (el) { el.textContent = new Intl.NumberFormat(locale()).format(parseInt(el.getAttribute("data-count"), 10)) + (el.getAttribute("data-suffix") || ""); });
    renderListings(); renderAreas(); updateCalc();
    if (aboutId) setAbout(byId(aboutId));
    if (current) renderModal();
  }
  $$(".lang_button").forEach(function (b) {
    b.addEventListener("click", function () { lang = b.getAttribute("data-lang"); try { localStorage.setItem("bogaz_lang", lang); } catch (e) {} applyI18n(); });
  });

  applyI18n();
})();
