(function () {
  "use strict";
  document.documentElement.classList.add("js");

  /* ---------- Traductions ---------- */
  var I18N = {
    tr: {
      navServices: "Hizmetler", navDuty: "Nöbetçi", navHours: "Saatler", navContact: "İletişim",
      call: "Ara", since: "1987'den beri · Cihangir",
      h1a: "İki kıta", h1b: "arasında", h1c: "şifa.",
      intro: "Beyoğlu'nun yokuşlarında, danışmanın bir çay kadar zaman aldığı mahalle eczanesi.",
      ctaWhatsapp: "WhatsApp'tan yaz", ctaDuty: "Nöbetçi eczane",
      stat1: "yıllık deneyim", stat2: "reçete hazırlama", stat3: "dilde danışmanlık", stat4: "ürün stokta",
      duty: "Nöbetçi eczaneler",
      dutyText: "Gece ve tatil günlerinde açık eczaneleri İstanbul Eczacı Odası'nın resmi sitesinden öğrenin.",
      dutyBtn: "Resmi listeyi aç",
      ticker: ["Nöbetçi eczane", "Şifa olsun", "7/24 bilgi", "Eve teslim"],
      svcTitle: "Mahallenin", svcSub: "reçetesi",
      svcLead: "Her ziyaret bir sohbetle başlar. İhtiyacınızı dinliyor, size en uygun çözümü birlikte buluyoruz.",
      s1t: "Reçeteler", s1d: "15 dakikada hazır, Avrupa yakasına eve teslim.",
      s2t: "Dermokozmetik", s2d: "Ücretsiz cilt analizi, yerli ve yabancı markalar.",
      s3t: "Majistral", s3d: "Laboratuvarımızda size özel formüller.",
      s4t: "Turistlere", s4d: "Türkçe ve İngilizce danışmanlık, 5 dakikada seyahat çantası.",
      quote: "Burada size sadece kutu satmıyoruz. Önce dinliyor, sonra iyileştiriyoruz.",
      author: "— Ecz. Ayşe Demir, mesul eczacı",
      hours: "Çalışma saatleri",
      d1: "Pazartesi — Cuma", d2: "Cumartesi", d3: "Pazar", d3h: "Nöbet günleri açık",
      today: "Bugün", open: "Şu an açık", closed: "Şu an kapalı",
      faqTitle: "Sık sorulanlar",
      q1: "E-reçete ile gelebilir miyim?", a1: "Evet. T.C. kimlik numaranız veya reçete kodunuz yeterli; ilaçlarınızı dakikalar içinde hazırlıyoruz.",
      q2: "Eve teslimat yapıyor musunuz?", a2: "Avrupa yakasında aynı gün teslimat. WhatsApp'tan yazmanız yeterli.",
      q3: "Yabancı reçeteleri kabul ediyor musunuz?", a3: "Reçetesiz satılabilen eşdeğer ürünleri öneriyoruz; gerekirse sizi uygun bir doktora yönlendiriyoruz.",
      directions: "Yol tarifi ↗", credit: "Demo — Webina", skip: "İçeriğe geç"
    },
    en: {
      navServices: "Services", navDuty: "On duty", navHours: "Hours", navContact: "Contact",
      call: "Call", since: "Since 1987 · Cihangir",
      h1a: "Healing", h1b: "between two", h1c: "continents.",
      intro: "A neighbourhood pharmacy on the hills of Beyoğlu, where advice takes the time of a glass of çay.",
      ctaWhatsapp: "Message on WhatsApp", ctaDuty: "On-duty pharmacy",
      stat1: "years of experience", stat2: "to fill a prescription", stat3: "languages spoken", stat4: "products in stock",
      duty: "On-duty pharmacies",
      dutyText: "Find pharmacies open at night and on holidays on the official Istanbul Chamber of Pharmacists website.",
      dutyBtn: "Open official list",
      ticker: ["On-duty pharmacy", "Get well soon", "24/7 info", "Home delivery"],
      svcTitle: "The neighbourhood", svcSub: "prescription",
      svcLead: "Every visit starts with a conversation. We listen to your needs and find the right solution together.",
      s1t: "Prescriptions", s1d: "Ready in 15 min, home delivery on the European side.",
      s2t: "Skincare", s2d: "Free skin analysis, Turkish and international brands.",
      s3t: "Compounding", s3d: "Custom formulas made in our own lab.",
      s4t: "Travellers", s4d: "Advice in English and Turkish, travel kit in 5 minutes.",
      quote: "We don't just sell you a box. We listen first, then we heal.",
      author: "— Pharm. Ayşe Demir, head pharmacist",
      hours: "Opening hours",
      d1: "Monday — Friday", d2: "Saturday", d3: "Sunday", d3h: "Open on duty days",
      today: "Today", open: "Open now", closed: "Closed now",
      faqTitle: "FAQ",
      q1: "Can I come with an e-prescription?", a1: "Yes. Your ID number or prescription code is enough; we prepare your medicines within minutes.",
      q2: "Do you deliver?", a2: "Same-day delivery on the European side. Just message us on WhatsApp.",
      q3: "Do you accept foreign prescriptions?", a3: "We suggest over-the-counter equivalents and, if needed, refer you to a suitable doctor.",
      directions: "Get directions ↗", credit: "Demo — Webina", skip: "Skip to content"
    }
  };

  var lang = "tr";
  // Langue mémorisée, sinon TR par défaut (EN si navigateur anglophone)
  var saved = null;
  try { saved = localStorage.getItem("lale-lang"); } catch (e) {}
  lang = saved || ((navigator.language || "").slice(0, 2) === "en" ? "en" : "tr");

  function setLang(l) {
    lang = I18N[l] ? l : "tr";
    var t = I18N[lang];
    document.documentElement.lang = lang;
    document.querySelectorAll("[data-i18n]").forEach(function (el) {
      var v = t[el.getAttribute("data-i18n")];
      if (typeof v === "string") el.textContent = v;
    });
    document.querySelector(".skip-link").textContent = t.skip;
    document.querySelectorAll(".lang_button").forEach(function (b) {
      var on = b.dataset.lang === lang;
      b.classList.toggle("is-active", on);
      b.setAttribute("aria-pressed", on);
    });
    buildMarquee(t.ticker);
    updateStatus();
    try { localStorage.setItem("lale-lang", lang); } catch (e) {}
  }

  document.querySelectorAll(".lang_button").forEach(function (b) {
    b.addEventListener("click", function () { setLang(b.dataset.lang); });
  });

  /* ---------- Bandeau défilant (dupliqué pour une boucle continue) ---------- */
  function buildMarquee(items) {
    var track = document.querySelector("[data-marquee]");
    var html = "";
    for (var i = 0; i < 4; i++) items.forEach(function (w) { html += "<span>" + w + "</span>"; });
    track.innerHTML = html + html;
  }

  /* ---------- Statut ouvert / fermé (heure d'Istanbul) ---------- */
  function istanbulNow() {
    var parts = new Intl.DateTimeFormat("en-GB", {
      timeZone: "Europe/Istanbul", weekday: "short", hour: "2-digit", minute: "2-digit", hour12: false
    }).formatToParts(new Date());
    var o = {};
    parts.forEach(function (p) { o[p.type] = p.value; });
    var days = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
    return { day: days[o.weekday], minutes: (parseInt(o.hour, 10) % 24) * 60 + parseInt(o.minute, 10) };
  }

  function updateStatus() {
    var now = istanbulNow(), t = I18N[lang], open = false;
    // Lun–Ven 08:30–21:00, Sam 09:00–20:00, Dim fermé (hors nöbet)
    if (now.day >= 1 && now.day <= 5) open = now.minutes >= 510 && now.minutes < 1260;
    else if (now.day === 6) open = now.minutes >= 540 && now.minutes < 1200;

    document.querySelectorAll("[data-status]").forEach(function (b) {
      b.classList.toggle("is-open", open);
      b.classList.toggle("is-closed", !open);
      b.querySelector("[data-status-text]").textContent = open ? t.open : t.closed;
    });

    document.querySelectorAll(".hours_row").forEach(function (row) {
      var r = row.dataset.day, isToday = r === "1-5" ? now.day >= 1 && now.day <= 5 : parseInt(r, 10) === now.day;
      row.classList.toggle("is-today", isToday);
      row.firstElementChild.setAttribute("data-today", t.today);
    });
  }
  setInterval(updateStatus, 60000);

  /* ---------- Menu mobile ---------- */
  var burger = document.querySelector(".nav_burger"), menu = document.getElementById("nav-menu");
  function closeMenu() { menu.classList.remove("is-open"); burger.setAttribute("aria-expanded", "false"); }
  burger.addEventListener("click", function () {
    var open = menu.classList.toggle("is-open");
    burger.setAttribute("aria-expanded", open);
  });
  menu.querySelectorAll("a").forEach(function (a) { a.addEventListener("click", closeMenu); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeMenu(); });

  /* ---------- Nav masquée au scroll descendant + parallax hero + bouton WhatsApp ---------- */
  var nav = document.querySelector("[data-nav]"), img = document.querySelector("[data-parallax]");
  var wa = document.querySelector(".whatsapp_float"), lastY = 0, ticking = false;
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function onScroll() {
    var y = window.scrollY;
    if (!menu.classList.contains("is-open")) nav.classList.toggle("is-hidden", y > lastY && y > 300);
    wa.classList.toggle("is-visible", y > window.innerHeight * 0.6);
    if (img && !reduce && y < window.innerHeight * 1.2) img.style.transform = "scale(1.08) translateY(" + y * 0.08 + "px)";
    lastY = y; ticking = false;
  }
  window.addEventListener("scroll", function () {
    if (!ticking) { requestAnimationFrame(onScroll); ticking = true; }
  }, { passive: true });

  /* ---------- Lien de nav actif ---------- */
  var links = document.querySelectorAll(".nav_link");
  var spy = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (!e.isIntersecting) return;
      links.forEach(function (l) { l.classList.toggle("is-current", l.getAttribute("href") === "#" + e.target.id); });
    });
  }, { rootMargin: "-45% 0px -50% 0px" });
  ["hizmetler", "nobet", "saatler", "iletisim"].forEach(function (id) {
    var s = document.getElementById(id); if (s) spy.observe(s);
  });

  /* ---------- Révélation + compteurs ---------- */
  function countUp(el) {
    var target = parseInt(el.dataset.count, 10), start = null, dur = 1400;
    if (reduce) { el.textContent = target.toLocaleString(lang === "en" ? "en-US" : "tr-TR"); return; }
    function step(ts) {
      if (!start) start = ts;
      var p = Math.min((ts - start) / dur, 1), eased = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(target * eased).toLocaleString(lang === "en" ? "en-US" : "tr-TR");
      if (p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (!e.isIntersecting) return;
      var el = e.target, siblings = Array.prototype.indexOf.call(el.parentNode.children, el);
      el.style.transitionDelay = Math.min(siblings, 4) * 90 + "ms";
      el.classList.add("is-visible");
      el.querySelectorAll("[data-count]").forEach(countUp);
      if (el.hasAttribute("data-count")) countUp(el);
      io.unobserve(el);
    });
  }, { threshold: 0.15 });
  document.querySelectorAll("[data-reveal]").forEach(function (el) { io.observe(el); });

  document.querySelector("[data-year]").textContent = new Date().getFullYear();
  setLang(lang);
})();
